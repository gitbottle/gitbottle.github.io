package lab7;

import list.OrderedList;
import list.UnorderedList;
import sort.Sort;

import java.util.Iterator;
public class ListApp {
	public static void main(String[] args){
		String[] str = {"hello","this","is","the","beginning"};
		UnorderedList<String> ulist = new UnorderedList<String>();
		OrderedList<String> olist = new OrderedList<String>();
		System.out.println("Adding items\n");
		for(String s : str){
			ulist.add(s);
			
			System.out.println(ulist);
			olist.add(s);
			
			System.out.println(olist);
			
		}
		try{
			System.out.println("Unorderd List\n");
			System.out.println(ulist);
			ulist.removeFirst();
			System.out.println("Unorderd List after removing the first item\n");
			System.out.println(ulist);
			System.out.println("orderd List\n");
			System.out.println(olist);
			
			System.out.println("Unorderd List using iterator\n");
			Iterator<String> it = ulist.iterator();
			while(it.hasNext())
				System.out.println("->" + it.next());
			System.out.println("last item in ordered list:");
			System.out.println(olist.last());
			
			System.out.println("first item in ordered list:");
			System.out.println(olist.first());
			System.out.println("Removing item in location 2:");
			olist.removeAtPosition(2);
			System.out.println(olist);
			System.out.println("Setting beginning with hey:");
			olist.set("beginning", "hey");
			System.out.println(olist);
			System.out.println("Resetting item 0 with beginning:");
			
			olist.set("beginning", 0);
			System.out.println(olist);
			
		}
		catch(Exception e){}
		System.out.println("Searching Unorderd List for item number 4\n");
		System.out.println(ulist.search(str[4]));
		System.out.println("Searching orderd List for item number 4\n");
		System.out.println(olist.search(str[4]));
		System.out.println("Searching Unorderd List for item, hello\n");
		System.out.println(ulist.search("hello"));
		System.out.println("Searching orderd List for item hello\n");
		System.out.println(olist.search("hello"));
		System.out.println("Searching Unorderd List for item Hello(capitalized h)\n");
		System.out.println(ulist.search("Hello"));
		System.out.println("Removing beginning from orderedlinst\n");
		olist.remove("beginning");
		ulist.remove("beginning");
		System.out.println("Removing beginning from orderedlinst\n");
		System.out.println(olist);
		System.out.println("Removing beginning from unorderedlinst\n");
		System.out.println(ulist);
		
		
		/*
		Integer[] x = {5, 4, 2, 6, 1, 7};
		Sort.insertionSort(x);
		for(int n : x)
			System.out.println(n);
		Sort.insertionSort(str);
		for(String s : str)
			System.out.println(s);
		*/
		
	}
}
