package project3packageJasmineKim;

public class Airline {
	//fields
	private String flightID;
	private long entered;
	private long exited;
	
	public Airline (String ID, long e) {
		flightID= ID;
		entered= e;
	}

	public String getID () {
		return flightID;
	}
	
	public long getEntered() {
		return entered;
	}
	
	public void setEntered (long e) {
		entered=e;
	}
	
	public void setExited(long x) {
		exited= x;
	}
	
	public String toString() {
		return flightID + " | Time entered: " + entered;
	}

}
