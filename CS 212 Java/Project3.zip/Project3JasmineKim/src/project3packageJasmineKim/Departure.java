package project3packageJasmineKim;

import java.util.Random;

import cs212lib.Queue;
import cs212lib.QueueFullException;

public class Departure extends Thread {
	
	private Queue <Airline> queue = new Queue <Airline> ();
	private int time;
	private boolean running=true;
	
	public Departure (int t) {
		time = t;
	}
	
	public Queue<Airline> getQueue () {
		
		return queue;
	}
	
	public int getTime () {
		
		return time;
	}
	
	
	public void run() {
		while (running) {
			//Use the timeTillnext method to simulate landing
			//use the sleep method
			//sleep
			//create a new Airline object- use the AIRLINES array from the simulation using Random.	
			//Add the new airline object to the queue.
			//print information about the airline.
			long nextEventTime;
			Random rand = new Random ();
			//rand.nextInt(b-a+1)+a
			//a=0 b=Simulation.AIRLINES.length
			int x= rand.nextInt((Simulation.AIRLINES.length-1)-0+1)+0;
			nextEventTime=Simulation.timeTillNext(time);
			
			Airline airline = new Airline (Simulation.AIRLINES[x],nextEventTime);
			try {
					sleep (time);
					queue.enqueue (airline);
					System.out.println ("Added flight "+airline.getID()+ " to the departure Queue");
			}catch (InterruptedException ie) {
				
					
			}catch(QueueFullException sfe) {
		
			}
			
		}
		
	}
	
	public void stopRunning() {
		running=false;
	}
	
	public String toString () {
		
		return "";
	}

}
