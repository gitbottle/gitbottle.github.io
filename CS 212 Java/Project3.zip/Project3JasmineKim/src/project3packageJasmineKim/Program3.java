package project3packageJasmineKim;

import java.awt.*;
import java.util.Random;

import javax.swing.JOptionPane;

public class Program3 {
	
	Arrival arrival;
	Departure departure;
	Runway runway;
	long startTime;
	long simulationTime;

	public static void main(String[] args) { 
		 
		/* TODO: 
		 
		Input the length of time to run the simulation (in minutes) 
		 Create an instance of Program3 
		 Call the startSimulation method and pass the time to it 
		 Loop while the Arrival or Departure threads are alive 
		 Stop the Runway thread from running 
		 
		*/  
		String input;
		input= JOptionPane.showInputDialog("Enter how long you want to run the simulation (in minutes)");
		Program3 program3 = new Program3 ();
		program3.startSimulation (Long.parseLong(input));

}
	

	public void startSimulation(long time) { 
	 
	startTime= System.currentTimeMillis();
	simulationTime= time*60000;
	
	arrival= new Arrival (Simulation.LANDING_TIME); 
	departure = new Departure (Simulation.TAKEOFF_TIME);
	runway = new Runway (arrival, departure);
		//TODO: Start each thread 
	
	arrival.start();
	departure.start();
	runway.start();
	 
	//Loop - run simulation for specified time while(System.currentTimeMillis() < startTime + simulationTime){ 
	while(System.currentTimeMillis() < startTime + simulationTime){ } //start as long as the current time. The time you specified wanted
	//to run the program for. 

// TODO: stop the loop in each thread � call the stopRunning method
	arrival.stopRunning();
	departure.stopRunning();
	runway.stopRunning();
// TODO: interrupt each thread � method from Thread class
	arrival.interrupt();
	departure.interrupt();
	runway.interrupt();
	
		try{

// TODO: wait for each thread to die � method from Thread class
			arrival.join();
			departure.join();
			runway.join();
		}catch(InterruptedException e){
			e.printStackTrace();
		}

}

}
