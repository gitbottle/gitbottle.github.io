package project3packageJasmineKim;
import cs212lib.Queue;
import cs212lib.QueueEmptyException;

public class Runway extends Thread {
	
	private Arrival arrival;
	private Departure departure;
	private boolean running = true;

	public Runway (Arrival a, Departure b) {
		arrival=a;
		departure=b;
	}
	
	public void run() { 
		
		Airline airline;
		
		while(running){ 
	 
		   try {
				//while there are planes in the arrival queue
			  	//hint: arrival.getQueue().isEmpty()
			  	while (!(arrival.getQueue().isEmpty())) {
				 
			  		airline=arrival.getQueue().dequeue();// store this to an airline object. 
			  		//then print information about the airline
			  		System.out.println ("Flight "+ airline.getID() + " cleared for landing - Entered Queue at "+ airline.getEntered() + " waited " );
			  		//then simulate the landing by calling
			  		sleep (Simulation.LANDING_TIME);
				   
				  }
			    
			  	
			  	
				while (!(departure.getQueue().isEmpty())) {
				   
					airline= departure.getQueue().dequeue();// store this to airline object. 
			  		//then print information about the airline
					System.out.println ("Flight "+ airline.getID() + " cleared for landing - Entered Queue at "+ airline.getEntered() + " waited " );
			  		//then simulate the landing by calling
			  		sleep (Simulation.TAKEOFF_TIME);
				   
					  
				  }
			}catch (QueueEmptyException qee) {
					
			}catch (InterruptedException ie) {
		  
	 
			}
		}
		
		System.out.println ("You've reached the end of runway");
}

	public void stopRunning() {
		running = false;
	}
	
	public String toString () {
		String str="";
		return str;
	}
}
