package project3packageJasmineKim;

import java.util.Random;

import cs212lib.Queue;
import cs212lib.QueueFullException;


public class Arrival extends Thread {
	
	private boolean running= true;
	//instantiate the object for Queue class. 
	//Queue <String> queue = new Queue <String> ();
	private Queue <Airline> queue = new Queue <Airline> () ;
	int time;
	
	public Arrival (int t){
		
		time= t;
		
	}
	
public Queue<Airline> getQueue(){
	
	return queue;
}

public int getTime() {
	
	return time;
}
	 
public void stopRunning () {
	running= false;
}

public void run(){ 
		
		while(running){ 
	 
						//Use the timeTillnext method to simulate landing
						//use the sleep method
						//sleep
						//create a new Airline object- use the AIRLINES array from the simulation using Random.	
						//Add the new airline object to the queue.
						//print information about the airline.
						long nextEventTime;
						Random rand = new Random ();
						//rand.nextInt(b-a+1)+a
						//a=0 b=Simulation.AIRLINES.length
						int x= rand.nextInt((Simulation.AIRLINES.length-1)-0+1)+0;
						nextEventTime=Simulation.timeTillNext(time);
						
						Airline airline = new Airline (Simulation.AIRLINES[x],nextEventTime);
						
						try {
								sleep (time);
								queue.enqueue (airline);
								System.out.println ("Added flight "+airline.getID()+ " to arrival Queue");
						}catch (InterruptedException ie) {
							
						}catch(QueueFullException sfe) {
					
						}
	} 
}

public String toString() {
	String str= "";
	   /*
	   if (queue.isEmpty()){
		   str+="There are no airlines on Arrival Queue";    
	      return str;}
	   else{
	      
	      str+= "\nThe arrival queue contains the following airlines: ";
	      for (int index=head; index<queue.getSize(); index++){
	      str= str+ queue.airline.flightID+" ";}
	      return str;}
	*/
	return str;
}

}
