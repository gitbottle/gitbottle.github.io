//package lab3a;
//Example of creating your own exception
/**
 * DateException default constructor - instantiates an exception object
 *without a parameter
 */
public class DateException extends Exception {
	public DateException() {
		super("Invalid value for Date");
	}
  /* DateException constructor - instantiates an exception object
   *@message is a string of message to be displayed
   */
	public DateException(String message) {
		super(message);
	}
}

