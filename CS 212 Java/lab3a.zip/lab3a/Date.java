//package lab3;

/**
 * <p>
 * Title: Date.java
 * </p>
 *
 * <p>
 * Description: Explore the use of System.in and validating input
 * Explore exception handling
 * Create and use a programmer-defined exception class
 * </p>
 *
 * <p>
 * Copyright: Copyright (c) 2016
 * </p>
 *
 * <p>
 * Company: Queens College
 * </p>
 *
 * @author Jasmine Kim
 * @version 1.0
 */

	public class Date {
		
		private int dMonth; // variable to store the month
		private int dDay; // variable to store the day
		private int dYear; // variable to store the year

		/**
		 * default constructor - sets dMonth=1, dDay=1, and dYear=1900
		 */
		public Date() {
			dMonth = 1;
			dDay = 1;
			dYear = 1900;
		}

		/**
		 * parameterized constructor - sets dMonth, dDay, and dYear to user
		 * specified values
		 * 
		 * @param month
		 *            value to be stored in dMonth
		 * @param day
		 *            value to be stored in dDay
		 * @param year
		 *            value to be stored in dYear
		 */
		public Date(int month, int day, int year) throws DateException {
			setMonth(month);
			setDay(day);
			setYear(year);
		}

		/**
		 * setDate - stores month, day, and year in dMonth, dDay, and dYear
		 * respectively be calling each of the setMethods defined
		 * 
		 * @param month
		 *            value to be stored in dMonth
		 * @param day
		 *            value to be stored in dDay
		 * @param year
		 *            value to be stored in dYear
		 */
		public void setDate(int month, int day, int year) throws DateException{
			setMonth(month);
			setDay(day);
			setYear(year);
		}

		/**
		 * setMonth - stores month in dMonth
		 * 
		 * @param month
		 *            the value to be stored in dMonth
		 */
		public void setMonth(int month) throws DateException//Not handling here, will throw above.
		{
			if (month >= 1 && month <=12) dMonth = month;
			else throw new DateException ("month out of range");
		}

		/**
		 * setDay - stores day in dDay
		 * 
		 * @param day
		 *            the value to be stored in dDay
		 */
		public void setDay(int day) throws DateException{
			if (day>=1 && day<=29)dDay = day;
         else throw new DateException ("Day out of range");
		}

		/**
		 * setYear - stores year in dYear
		 * 
		 * @param year
		 *            the value to be stored in dYear
		 */
		public void setYear(int year) throws DateException {
			
         if (year>=1752 && year<=2018){ 
            if ((!isLeapYear(year))&& (dMonth==2) && (dDay==29)){
               throw new DateException ("Non-Leap years cannot have 29th day in February");}               
            else dYear = year;
         }
         else throw new DateException ("Year out of range");
       
		}
      /**
      isLeapYear method 
      @param year the year
      @return true if a year is leap year
      */
      
      private boolean isLeapYear (int year){
        
            if ((year %4==0)&& (year%100!=0))
                  return true;
            else if ((year%4==0)&&(year%100==0)&& (year%400==0))
                   return true;
                  
            else return false;
                                                     
       }

		/**
		 * getMonth - accessor for dMonth
		 * 
		 * @return returns the value stored in dMonth
		 */
		public int getMonth() {
			return dMonth;
		}

		/**
		 * getDay - accessor for dDay
		 * 
		 * @return returns the value stored in dDay
		 */
		public int getDay() {
			return dDay;
		}

		/**
		 * getYear - accessor for dYear6
		 * 
		 * 
		 * @return returns the value stored in dYear
		 */
		public int getYear() {
			return dYear;
		}

		/**
		 * toString - returns the month, day, and year in the format: mm-dd-yyyy;
		 * leading zeros are NOT contained within the string
		 * 
		 * @return a String containing the date in month-day-year format
		 */
		public String toString() {
			return (dMonth + "-" + dDay + "-" + dYear);
		}
	}


