//package lab3;

/*Unchecked exceptions such as array bounds problem,
the compiler does not force you to create try and catch block.
also mismatch of types also unchecked exception. runtime exceptions
Checked exceptions we need to handle it yourself. try and catch
File input output add throws - we are not going to 
handle it or pass it up to whoever found it. -*/

import java.util.Scanner;
import java.util.InputMismatchException;

public class Lab3App {

	public static void main (String []args) {
	
		Scanner scan = new Scanner (System.in);
		int month, day, year;
		Date aDate= new Date ();
		boolean mdone=false;
      boolean ddone=false;
      boolean ydone=false;
     
		
		
	 while (!mdone){	
		  try{
		      System.out.print ("Enter the month as an integer");
				month= scan.nextInt();
            aDate.setMonth (month);
            mdone=true;
            
        }catch (DateException ex){
            System.out.println("DateException: " + ex.getMessage());
            scan.nextLine ();
        }catch (InputMismatchException ime){
		  
			  System.out.println ("Invalid input entered. Enter an integer");
			  scan.nextLine ();
        }catch (RuntimeException re){
		    System.out.println ("Invalid input entered. Enter an integer");
        }
    }	  
     
     while (!ddone){    
        try{
	         
            System.out.print ("Enter the day as an integer");
				day= scan.nextInt();
            aDate.setDay (day);
            ddone=true;
            
        }catch(DateException ex){
            System.out.println("DateException: " + ex.getMessage());
            scan.nextLine ();
        }catch (InputMismatchException ime){
		  
			  System.out.println ("Invalid input entered. Enter an integer");
			  scan.nextLine ();
        }catch (RuntimeException re){
		    System.out.println ("Invalid input entered. Enter an integer");
        }
	  }
     
     while (!ydone){
        try{
	         
            System.out.print ("Enter the year as an integer");
				year= scan.nextInt();
            aDate.setYear (year);
            ydone=true;
            
        }catch(DateException ex){
            System.out.println("DateException: " + ex.getMessage());
		      scan.nextLine ();
        }catch (InputMismatchException ime){
        	   System.out.println ("Invalid input entered. Enter an integer");
			   scan.nextLine ();
        }catch (RuntimeException re){
		      System.out.println ("Invalid input entered. Enter an integer");
        }
    
     }   
            
				//aDate = new Date (month,day,year);//question five. the program will not throw exception until this point because the constructor is created here. 
		/*		
		  } catch (InputMismatchException ime){
		  
			  System.out.println ("Invalid input entered. Enter an integer");
			  scan.nextLine ();
           
           
           
		  } catch (RuntimeException re)
		  {
			  System.out.println ("Invalid input entered. Enter an integer");
			  
		  } catch (DateException ex) 
		  {
			  System.out.println("DateException: " + ex.getMessage());
		  }
		  
		  //inputmismatch exception is a subclass of runtime exception. So you need to put the 
		  //specific exception first then more general ones later. First put the inputmismatch then runtime
		  */
		
      System.out.println (aDate);
      
	}
}


