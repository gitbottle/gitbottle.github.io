package lab6b;

public class OrderedArrayList <T extends Comparable<T>> extends ArrayList <T> {

	
	public boolean add(T insertItem) {
		// TODO Auto-generated method stub
		if (isFull()) {
			System.out.println ("The linkedlist is full. Was not able to add the new line");
			return false;
		}
		
		else if (size==0) {
			data[size]=insertItem;

			size++;
			System.out.println("first item successfully added");
			
			return true;
			
		}
		
		else {
			int i=0;
			while (insertItem.compareTo(data[i])>0 ){
				
				i++;	
				if (i==size) break;
			}
			
			System.out.println("i= "+i);
			
			if (data[i]!=null) {
				//shifting
				for (int j= size-1; j>=i; j--) {
					data[j+1]=data[j];
					System.out.println ("Shifted and new item added at "+i);
				}
			
			}
					
				data[i]= insertItem;
				size++;
				return true;
			}
		}
	

	@Override
	public int indexOf(T searchItem) {
		// TODO Auto-generated method stub
		int count = 0;


		while (count<size) {
			if (data[count].equals(searchItem)) {
				return count;
			}

			count++;
		}

		return -1;
	}
	@Override
	public int lastIndexOf(T searchItem) {
		// TODO Auto-generated method stub

		int count = size-1;


		while (count>=0) {
			if (data[count].equals(searchItem)) {
				return count;
			}

			count--;
		}

		return -1;
	}

	@Override
	public boolean contains(T searchItem) {
		// TODO Auto-generated method stub
		if (indexOf(searchItem)==-1) return false;
		
		return true;
	}

	@Override
	public T get(int index) {
		// TODO Auto-generated method stub
		if(index>=0 && index<size) {
			
			return data[index];
		}
		
		return null;
	}

	@Override
	public T remove(T removeItem) {
		// TODO Auto-generated method stub
		if(indexOf(removeItem)==-1) {
			System.out.println ("the item was not found");
			return null;
		}
	
		int spot= indexOf(removeItem);
		
		for (int i=spot; i<size-1; i++) {
			data[i]=data[i+1];
			}
		System.out.println (removeItem+" removed successfully");
		size--;
		
		return removeItem;
	}

	@Override
	public T remove(int index) {
		// TODO Auto-generated method stub
		if (index<size && index>=0) {
			T save = data[index];
			
			for (int i=index; i<size-1; i++) {
				data[i]= data[i+1];
			}
			
			System.out.println (save+" removed successfully");
			size--;
			return save;
		}
		
		System.out.println ("The item was not found");
		return null;
	}



	

}
