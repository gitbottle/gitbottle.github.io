package lab6b;

import java.util.Scanner;

public class ScannerDelimitor {
	public static void main (String [] args) {
		int number;
		String line;
		String input = "1	When a communications site transmits a message through a pac";
		Scanner s = new Scanner(input).useDelimiter("\t");
		
		number= s.nextInt();
		line= s.next();
		
		System.out.println(number);
		System.out.println(line);
	}
}
