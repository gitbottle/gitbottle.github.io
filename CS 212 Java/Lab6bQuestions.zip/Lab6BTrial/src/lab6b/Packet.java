package lab6b;

public class Packet implements Comparable <Packet> {
	
	private int index;
	private String line;
	
	public Packet (int n, String str) {
		
		index = n;
		line= str;
		
	}
	


	public int compareTo(Packet t) {
		// TODO Auto-generated method stub
		//you are comparing the string.
		return this.index - t.index;		
	}
	
	public int getIndex() {
		return index;
	}
	
	public String getLine() {
		return line;
	}

	public String toString() {
		
		
		return line+"\n";
	}
	
	
	
	
	//int result = prodId.compareTo(otherProduct.prodId);
	//return result;
	


//read in the index. File input/output, or Scanner class. retrieve the integer of the line. place the ilne in the correct sopt. parse the character numbers. 
//packet as one line of array. 
}
