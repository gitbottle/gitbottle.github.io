package lab6b;

public class UnorderedArrayList <T> extends ArrayList<T> {
	/**
     * default constructor - creates a list that can store 100 items;<br>
     * the size of the list is initialized to 0
     */	
	public UnorderedArrayList() {
		//super (); This line is not necessary. If you do not specify, it will call super automatically. 
	}
	/**
     * parameterized constructor - allows the user to specify the maximum capacity of the list.<br>
     * The list created can store at most <i>capacity</i> items; the size of the list is initialized to 0.
     * @param capacity indicates the maximum capacity of the list as specified by the user
     */	
	public UnorderedArrayList (int capacity) {
		super (capacity);
	}
	  /**
     * Returns the index of the first occurrence of the specified item (key) in this list
     * @param searchItem is a reference to an item whose key-field has been initialized
     * @return the location of the first occurrence of the specified item in this list; 
     * if searchItem is not found, -1 is returned
     */
	@Override
	public boolean add(T insertItem) {
		// TODO Auto-generated method stub
		//true if you successfully added an item. 
		if (isFull())
		return false;
		
		data[size] = insertItem;
		size++; //or data[size++];
		return true;
		
	}
	/**
     * Returns the index of the first occurrence of the specified item (key) in this list
     * @param searchItem is a reference to an item whose key-field has been initialized
     * @return the location of the first occurrence of the specified item in this list; 
     * if searchItem is not found, -1 is returned
     */
	@Override
	public int indexOf(T searchItem) {
		// TODO Auto-generated method stub
		//Use a loop to search for the item
		//Hint: use the.equals()method
		//return the index # if found, otherwise return -1 if not found.
		
		int count = 0;
		
		
		while (count<size) {
			if (data[count].equals(searchItem)) {
				return count;
			}
				
			count++;
		}
		
		return -1;
	}
	 /**
     * Returns the index of the last occurrence of the specified item (key) in this list
     * @param searchItem is a reference to an item whose key-field has been initialized
     * @return the location of the last occurrence of the specified item in this list; 
     * if searchItem is not found, -1 is returned
     */
	@Override
	public int lastIndexOf(T searchItem) {
		// TODO Auto-generated method stub
		int count = size-1;
		
		
		while (count>=0) {
			if (data[count].equals(searchItem)) {
				return count;
			}
				
			count--;
		}
		
		return -1;
	}
	
	/**
     * contains method - determines whether or not the searchItem (key)is in this list
     * @param searchItem is a reference to an item whose key-field has been initialized
     * @return <i>true</i> if the item is in this list, <i>false</i> otherwise 
     */
	@Override
	public boolean contains(T searchItem) {
		// TODO Auto-generated method stub
		//find search item, return true if found return false if not
		if (indexOf(searchItem)==-1) return false;
		
		else return true;
	}
	/**
     * get method - returns the item at the specified location in this list
     * @param index is the index of the item in this list
     * @return the item, if it is in this list, otherwise null is returned
     */
	@Override
	public T get(int index) {
		// TODO Auto-generated method stub
		//make sure index is within the correct range. return item at index. 
		//make sure index>=0 && index <size. 
		//if not return null. return null;
	
		//return item at index
		
		if (index>=0 && index<size) {
			
			return data[index];
		}
		
		else return null;
	}	
	/**
     * Removes the first occurrence of the specified item from this list, if it is present
     * @param removeItem is a reference to an item whose key-field has been initialized
     * @return the item, if it is in this list, otherwise null is returned
     */
	@Override
	public T remove(T removeItem) {
		// TODO Auto-generated method stub
		//first find the removeItem in the array
		//return null if the item is not found;
		//first store the item found in a variable.
		//you have to shift all the other elements to the left to fill the gap.
		//decrease size by one.
		int spot;
		
		
		if (indexOf(removeItem)==-1) {System.out.println(removeItem+ " not found"); return null;}
		
				spot= indexOf(removeItem);
				
				//shifting
				for (int i=spot; i<size-1; i++) {
					data[i]= data[i+1];
				}
				size--;
				System.out.println(removeItem +" removed successfully");
				return removeItem;
		
	}
	 /**
     * Removes the item at the specified location from this list, if it is present
     * @param index is the index of the item in this list
     * @return the item, if it is in this list, otherwise null is returned
     */
	@Override
	public T remove(int index) {
		// TODO Auto-generated method stub
		//first check if index is within the correct range, if not, return null. 
		//otherwise  remove item at index..do the same as aobe.
		
		
		T item;
		
		if (index>=0 && index<size) {
			
			
			item= data[index];
			//shifting
			for (int i=index; i<size-1; i++) {
				data[i]= data[i+1];
			}
			size--;
			System.out.println (item+ " removed successfully");
			return item;
		}
		
			System.out.println ("Item not found");
			
			return null;
		
	}
	
}
