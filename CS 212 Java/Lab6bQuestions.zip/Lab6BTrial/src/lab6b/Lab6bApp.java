package lab6b;


import java.util.Scanner;
import java.io.*;

public class Lab6bApp {
	
	public static void main (String []args) {
		
		
		Scanner scan=null;
		OrderedArrayList <Packet> orderedList = new OrderedArrayList<>();
		int index;
		String line;
		Scanner toSeperate=null;
		
		
		try {
			scan= new Scanner (new File("packet.dat.txt"));
			
			while(scan.hasNextLine()) {
				toSeperate = new Scanner (scan.nextLine()).useDelimiter("\t");
				index = toSeperate.nextInt();
				line= toSeperate.next();
				Packet p = new Packet(index,line);
				orderedList.add(p);
			}
		}catch(IOException e) {
			System.out.println("Error accessing file");
			e.printStackTrace();
		}
		
		
			System.out.println (orderedList);
			
		
		
		
		
		scan.close();
		toSeperate.close();
	}

}
