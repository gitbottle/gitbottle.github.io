import java.util.StringTokenizer;

public class TokenTest {

   public static void main (String [] args){
   
      String expression = "(12-3)*2+3*4";
      String delims="+-*/() ";
      StringTokenizer strToken = new StringTokenizer (expression, delims, true);
      
      while (strToken.hasMoreTokens()){
            String token= strToken.nextToken();
            System.out.println(token);
      
      }
   
   
   
   }
   
}