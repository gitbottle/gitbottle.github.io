//package generics;
/**
 * <p>
 * Title: The StackEmptyException Class
 * </p>
 * 
 * <p>
 * Description: Defines the behaviors of exception thrown when the stack is empty.
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * 
 * @author J. Kim
 * @version 0.9
 */
public class StackEmptyException extends Exception {
	/**
	 * Constructs a new StackEmptyException with a default error message string.
	 */
	public StackEmptyException(){
		super("Exception : Stack is empty");
	}
	/**
	 * Constructs a new StackEmptyException with the parameter as the error message string.
	 * @param msg The string passed as the error message string.
	 */
	public StackEmptyException(String msg){
		super(msg);
	}
}
