
/**
 * Staff is a child class of Employee. 
 * Need to implement the pay abstract method
 *
 * @Jasmine Kim
 * @version (a version number or a date)
 */
public class Staff extends Employee implements Comparable
{
    // instance variables - replace the example below with your own
    private double salary=1500;

    /**
     * Constructor for objects of class Staff
     */
    public Staff(String n, String i, String o, double s)
    {
        // initialise instance variables
        super (n, i, o);
        salary= s;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public double pay() //acts getpay method
    {
        // put your code here
        return salary;
    }
    
    public void setSalary(double s)
    {
        salary = s;
    }
    
    public int compareTo (Object o)
    {
        if (o instanceof Faculty)
        {
            Faculty f = (Faculty) o;
            
            
            if (this.pay()<f.pay()) 
            {   
                System.out.println("Salary of staff is less than that of faculty");
                return -1;
            }
            else if (this.pay()> f.pay())
            {
                System.out.println ("Salary of staff is more than that of faculty");
                return 1;
            }
            else 
            {
                System.out.println ("Salary of staff is equal to that of faculty");
                return 0;
            }
              
            
          
        }
        
        if (o instanceof Staff)
        {
            Staff s = (Staff) o;
            
            
            if (this.pay()<s.pay()) 
            {   
                System.out.println("Salary of this staff is less than that of faculty");
                return -1;
            }
            else if (this.pay()> s.pay())
            {
                System.out.println ("Salary of this staff is more than that of faculty");
                return 1;
            }
            else 
            {
                System.out.println ("Salary of this staff is equal to that of faculty");
                return 0;
            }
        }
         else {System.out.println ("Invalid input"); return 0;}
              
            
          
        }
    }

