
/**
 * Abstract class Employee - Parent class for Faculty and Staff classes
 *
 * @Jasmine Kim
 * 
 */
public abstract class Employee extends Person
{
    // instance variables - replace the example below with your own
    private String office;

    public Employee (String n, String i, String o)
    {
        super (n,i);
        office=o;
    }
    
    public abstract double pay ();
    
    public String toString()
    {
        // put your code here
        String str = super.toString ();
        str+= "\nWeekly Salary: "+ pay();
        return str;
    }
    
    public void setOffice (String o)
    {
        office=o;
    }
    
    public String getOffice ()
    {
         return office;
    }
}
