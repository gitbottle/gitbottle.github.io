

public class Faculty extends Employee implements Comparable
{
    // instance variables - replace the example below with your own
    private double hour, rate;

    /**
     * Constructor for objects of class Faculty
     */
    public Faculty(String n, String i, String o, double h, double r)
    {
        // initialise instance variables
        super(n, i, o);
        rate= r;
        hour=h;
    }

    
    public double pay ()
    {
        // put your code here
        return hour * rate;
    }
    
    public int compareTo (Object o)
    {
        if (o instanceof Faculty)
        {
            Faculty f = (Faculty) o;
            
            
            if (this.pay()<f.pay()) 
            {   
                System.out.println("Salary of faculty is less than that of staff");
                return -1;
            }
            else if (this.pay()> f.pay())
            {
                System.out.println ("Salary of faculty is more than that of staff");
                return 1;
            }
            else 
            {
                System.out.println ("Salary of faculty is equal to that of staff");
                return 0;
            }
              
            
          
        }
        
        if (o instanceof Staff)
        {
            Staff s = (Staff) o;
            
            
            if (this.pay()<s.pay()) 
            {   
                System.out.println("Salary of faculty is less than that of staff");
                return -1;
            }
            else if (this.pay()> s.pay())
            {
                System.out.println ("Salary of faculty is more than that of staff");
                return 1;
            }
            else 
            {
                System.out.println ("Salary of faculty is equal to that of staff");
                return 0;
            }
        }
         else {System.out.println ("Invalid input"); return 0;}
              
            
          
        }
        
        public void setHour (double h)
        {
            hour=h;
        }
        
        public void setRate (double r)
        {
            rate=r;
        }
        
        public double getHour ()
        {
            return hour;
        }
        public double getRate ()
        {
            return rate;
        }
}
