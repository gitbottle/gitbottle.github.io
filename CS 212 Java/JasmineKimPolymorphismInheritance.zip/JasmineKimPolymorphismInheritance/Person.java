
/**
 * Person is the base/parent class
 *
 * @Jasmine Kim
 * 
 */
public class Person
{
    // instance variables - replace the example below with your own
     protected String name, id;

    /**
     * Constructor for objects of class Person
     */
    public Person(String n, String i)
    {
        // initialise instance variables
        name = n;
        id = i;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public String toString( )
    {
        // put your code here
        String str= " ";
        
        str+= "\nName: "+ name+"\nID: "+id;
        str+="\nEmail: "+ email();
        return str;
    }
    
    public String email ()
    {
        String [] arrayName = name.split (" ");//split after space
        return name.charAt(0) + arrayName[1]+"@qc.cuny.edu";
    }
    
    public String getName ()
    {
        return name;
    }
    
    public String getId ()
    {
        return id;
    } 
    
    public void setName (String n)
    {
        name=n;
    }
    
    public void setId (String i)
    {
        id=i;
    }
}
