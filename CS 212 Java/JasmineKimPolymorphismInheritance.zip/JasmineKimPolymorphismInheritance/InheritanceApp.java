public class InheritanceApp
{
    
    public static void main (String [] args)
    {
         Faculty faculty = new Faculty("Dave Watson", "N00543210", "B3038", 49, 35);
   	 Staff staff = new Staff("Mary Smith", "N00975310", "C3078", 2000);
   	 Student student = new Student("John Doe", "N00123456", 2.54);
   	 System.out.println(faculty);
   	 System.out.println(student);
   	 System.out.println(staff);
   	 System.out.println ("After Late or dynamic binding");
   	 
   	 Person[] person = new Person[] { faculty, staff, student };
   	
   	 for (int i = 0; i < person.length; i++)
   		 System.out.println(person[i]);
   	
   	faculty.compareTo (staff);
   	staff.compareTo (faculty);
    }
}
