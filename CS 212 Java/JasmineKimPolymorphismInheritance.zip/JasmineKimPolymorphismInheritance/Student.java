

public class Student extends Person
{
    // instance variables - replace the example below with your own
    private double gpa;

    /**
     * Constructor for objects of class Student
     */
    public Student(String n, String i, double g)
    {
        // initialise instance variables
        super (n, i);
        gpa=g; 
    }

      public double getGpa ()
    {
   	 return gpa;
    }
    
    public void setGpa (double g)
    {
   	 gpa=g;
    }

}
