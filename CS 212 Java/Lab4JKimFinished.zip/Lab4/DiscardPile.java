//import generics.Stack;

/**
 * <p>
 * Title: The DiscardPile Class
 * </p>
 * 
 * <p>
 * Description: 
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * 
 * @author J. Kim
 * @version 0.9
 */
public class DiscardPile extends Stack <Card> {
//DiscardPile is an array/stack of Cards.
   //Discard constructor- no param
   public DiscardPile (){
      super (52); //size is 0 by default. The max size should be 52 just as a card stack.
   }
 /**  
   removeTopCards method 
   @param theCard to compare with cards in the discardPile
   @return saveCard array with the popped cards
   @Throws StackEmptyException if discardPile is empty or if the card was not found.
 */
 Card [] removeTopCards (Card theCard)throws StackEmptyException{
      //use pop, peek, isEmpty() methods for this method. 
      //pop method throws a new StackEmpty Exception, subclass of of exception class, si checked. has to be handled.
      //so surround it with try and catch block in the area where it is called. 
   int size=getSize();
   Card [] saveCard= new Card[size];
   boolean found=false;
   int c=0;
  
          
          
        if (isEmpty())throw new StackEmptyException ("The stack is empty");
        
         //Check if the pile contains the same card as the card passed in. Loop until the last item of discardPile
         //is reached or until the card is found. 
         //s1.equals(s2) to compare objects     
        while (!found){
           
           if (peek().equals(theCard)) {found=true;System.out.println("Card "+theCard+ " found!");}
           saveCard[c]= pop();
           c++;
           
           if (isEmpty()) break; 
           
         }
         
         //if card is found, return saveCard array. If not, throw an exception.    
         if (found) return saveCard;
         else {
         
            
            throw new StackEmptyException ("the card was not found");  
             
           }
            
      } 
           
       //return theCard AND the crards on top of theCard as a Card[]Array
      //otherwisds, if the card is not found, it shoudl throw an exception and handled at App4Lab.java
      //if the card wasn't found, amke sure you push it back onto the stack.
      
   
   }
