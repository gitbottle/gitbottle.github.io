public class Lab4App{
   public static void main (String [] args){
   
      DiscardPile discardPile = new DiscardPile ();
      
      discardPile.push(new	Card(8));		
      discardPile.push(new	Card(32));		
      discardPile.push(new	Card(48));		
      discardPile.push(new	Card(2));			
      discardPile.push(new	Card(17));		
      discardPile.push(new	Card(20));		
      discardPile.push(new	Card(25));		
      discardPile.push(new	Card(50));		
      discardPile.push(new	Card(19));		
      discardPile.push(new	Card(41));
      
      System.out.println(discardPile);//Show the current card pile. toString from Stack used.
      
      Card theCard = new Card (20);//Creating a new card to compare with the card pile.
   
      Card [] cardArray = new Card [discardPile.getSize()]; 
      
      int originalSize= discardPile.getSize();
      
      System.out.println ("\nLooking for card, "+theCard);
      
      try{
            cardArray= discardPile.removeTopCards(theCard);	
            System.out.println("Displaying the array of removed cards:");
            for(int i=(originalSize-(discardPile.getSize())-1); i>=0; i--){
               System.out.println (cardArray[i]);//uses the toString method defined in the Card class. 
            }
      }catch (StackEmptyException see) {
         System.out.println("StackEmptyException: "+see.getMessage());
      
      }      
   
      
      
      //Emptying the discardPile
      
      System.out.println ("\nEmptying the stack for the next activity");
      
    try{
         while (!discardPile.isEmpty())
         {
           System.out.println("Removing "+discardPile.pop());
          }
     }catch (StackEmptyException see){
       System.out.println("StackEmptyException: "+see.getMessage()); 
     } 
      
      System.gc();
      System.out.println ("\nRepopulating the stack");
 
      //Repopulating the discardPile 
      discardPile.push(new	Card(8));		
      discardPile.push(new	Card(32));		
      discardPile.push(new	Card(48));		
      discardPile.push(new	Card(2));			
      discardPile.push(new	Card(17));		
      discardPile.push(new	Card(20));		
      discardPile.push(new	Card(25));		
      discardPile.push(new	Card(50));		
      discardPile.push(new	Card(19));		
      discardPile.push(new	Card(41));  
      
       Card nextCard = new Card (16);
       
       System.out.println ("\nLooking for card, "+ nextCard);
       originalSize= discardPile.getSize();
             
      try{
            cardArray= discardPile.removeTopCards(nextCard);	
            System.out.println("Displaying the array of removed cards:");
            for(int i=(originalSize-(discardPile.getSize())-1); i>=0; i--){
               System.out.println (cardArray[i]);//uses the toString method defined in the Card class. 
            }
        
      }catch (StackEmptyException see) {
         System.out.println("StackEmptyException: "+see.getMessage());
      
      }

      
   }
}