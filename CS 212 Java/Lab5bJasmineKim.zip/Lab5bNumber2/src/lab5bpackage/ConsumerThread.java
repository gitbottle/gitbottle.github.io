package lab5bpackage;

import cs212lib.Queue;
import cs212lib.QueueEmptyException;

import java.util.Random;

import javax.swing.JOptionPane;

public class ConsumerThread extends Thread {

	private Queue<String> queue;
	private ProducerThread producer;
	private int count=0;
	private PictPanel panel;
	private boolean running;
	
	// TODO: constructor
	//		initialize the queue, producer thread, and the panel 
	//		using the 3 parameters
	
	public ConsumerThread(Queue<String> q, ProducerThread pd, PictPanel p) {
		queue= q;
		producer = pd;
		panel = p;
	}
	
	
	public void run() {	
		// TODO loop while the producer thread isAlive or the queue is not empty
		//	Note:	possible exceptions that can occur are 
		//		QueueEmptyException and InterruptedException
		while (producer.isAlive() || !queue.isEmpty())
		{
				// TODO loop while the queue is empty
				while (queue.isEmpty()) {}
				try {
				// TODO if the queue is not empty
				if (!queue.isEmpty())
				{
					//	take an item from the queue
					
					//	call the panel's drawPict method and pass the item
					panel.drawPict(queue.dequeue());
					//	Use Thread.currentThread().getName() to output
					//		the name of this thread and the item it processed	
					System.out.println(Thread.currentThread().getName());
					count++;
					//	add 1 to the count
					Random rand = new Random ();
					//	sleep for 1000 to 5000 milliseconds (random)
					
					sleep (rand.nextInt(5000-1000+1)+1000);
				}
				
				} catch (QueueEmptyException qe) {
					System.out.println("QueueEmptyException");
				}catch (InterruptedException qi) {
					System.out.println("InterruptedException");
				}
				
		}
		// TODO When the thread stop's running, 
		//		display its name and the number of items processed	
		
		JOptionPane.showMessageDialog(null,Thread.currentThread().getName() + " "+count);
	} 

}

