package lab5bpackage;


import cs212lib.Queue;
import cs212lib.QueueFullException;
import javax.swing.JOptionPane;
import java.util.Random;

public class ProducerThread extends Thread {
	
	private Queue<String> queue;
	private String[] picture;

	//TODO: constructor
	//	initialize the queue and the array
	//	using the 2 parameters
	
	public ProducerThread(Queue<String> q, String[] p) {
		
		queue= q;
		picture=p;
	}


	public void run() {
		//	TODO loop for each picture and the picture is not null
		//	Note: possible exceptions that can occur are
		//		QueueFullException and InterruptedException
		int count=0;
		while (count < picture.length && picture[count]!=null)
		{
			//	TODO loop while the queue is full
			while (queue.isFull()) {}
		  try {
			//	TODO add an item from the array to the queue
			queue.enqueue(picture[count]);
			//		display the item added to the queue
			//JOptionPane.showMessageDialog (null, picture[count]);
			//		sleep for 100 - 1000 milliseconds
			
			
			Random rand = new Random ();
		
			sleep (rand.nextInt(1000-100+1)+100);
			
			count++;
			
		  }catch (QueueFullException qfe) {
			  
			  System.out.println("QueueEmptyException");
		  }catch (InterruptedException qi ) {
			  System.out.println("InterruptedException");
			  
		  }
		}
		
		
		  
		//	TODO When the thread stop's running,
		//	display a message indicating the thread has stopped
		JOptionPane.showMessageDialog(null,"Thread has stopped working");
		
		
	}
	
}
