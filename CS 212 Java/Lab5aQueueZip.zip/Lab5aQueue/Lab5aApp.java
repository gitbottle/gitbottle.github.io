public class Lab5aApp{

   public static void main (String []args)throws QueueException{
   
      //Question 4
      Queue <Integer> queue1 = new Queue <Integer> ();
      System.out.println (queue1);
      //Question 5
      Queue <Integer> queue2 = new Queue <Integer> (3);
      //Question 6 & 7
      queue2.enqueue(new Integer(4));
      System.out.println (queue2);
      //Question 8
      queue2.enqueue(new Integer(7));
      queue2.enqueue(new Integer(2));
      System.out.println(queue2);
      
      
      //Question 9 throws emptyException.Need try and catch block.
      //queue2.enqueue(new Integer(0));
      
      //Question 10 & 13
      if(queue1.isEmpty()) System.out.println ("The queue1 is empty");
      if(queue2.isFull()) System.out.println ("The queue2 is full");
      
      //Question 11 testing front and rear methods
        //Testing the queue that contains data. 
      System.out.println("First item on queue2 is: "+queue2.front());
      System.out.println("Last item on queue2 is: "+queue2.rear());
       //Testing the queue that is empty. Throws exception. need try and catch.
      //System.out.println("First item on queue1 is: "+queue1.front());
      //System.out.println("Last item on queue1 is: "+queue1.rear());
      
      //Question 12
      queue2.dequeue();//dequeued 4
      queue2.dequeue();//dequeued 7
      queue2.dequeue();//dequeued 2
      //queue2.dequeue();throws exception
      
     //Repopulating the queue1 to test the makeEmpty() method.
     queue1.enqueue (5); 
     queue1.enqueue (6);
     queue1.enqueue (7);
     
     queue1.makeEmpty();
     
     if (queue1.isEmpty())System.out.println ("makeEmpty() method works. The queue1 has been emptied"); 
     else System.out.println ("makeEmpty() method failed.");
  }
}