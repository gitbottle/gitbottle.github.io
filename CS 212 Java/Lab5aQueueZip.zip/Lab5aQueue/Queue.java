public class Queue <T> implements QueueADT <T>{
	//Fields
   private T[] data;
	private int size;
	private int head;//index # of the front of the queue
	private int tail;//index # of the back of the queue
	private static final int MAX_SIZE = 100;

/* Queue default constructor
*  Sets size, head, and tail equal to zero and carves out memory space for data array.
*/	
public Queue () {
	
	data = (T[]) new Object [MAX_SIZE];//() means to type cast into T. 
	size = 0;
	head = 0;//Some texts set this to -1
	tail = 0;
}
/* Queue constructor
*  @param s the size of the data array
*/

public Queue (int s) {
	
	data = (T[]) new Object [s];
	size = 0;
	head = 0;//Some textbooks set this to -1
	tail = 0;
}

/* enqueue method adds an item to the queue
*  @param x item to add on the queue
*/
public void enqueue (T x) throws QueueException{
	
	if (isFull()) throw new QueueException("The queue is full");
	else {
		
			data[tail] = x;
			tail= (tail+1)%(data.length);
         size++;
		}
			
	
	}
/* dequeue method takes out an item from the queue
*  @return T removed item
*/
public T dequeue () throws QueueException {
	
	if (isEmpty()) throw new QueueException ("The queue is empty");
	else {
	   	  T save= data[head];
	        head= (head+1)%data.length;
	        size--;
	        return save;
	 		
	      }
}

/* isFull method  
*  @return true if the queue is full
*/

public boolean isFull () {
	
	if (size==data.length) return true;
	else return false;
	
	//or simply return size==data.length;
	
}
/* isEmpty method  
*  @return true if the queue is empty
*/
public boolean isEmpty () {
	if (size==0) return true;
	else return false;
	//or simply return size==0;
}

/* getSize method 
*  @return int current size of the queue
*/

public int getSize () {
	
	return size;
}

/* front method  
*  @return T the item that is at the front of the queue
*/
public T front() throws QueueException {
	if (isEmpty()) throw new QueueException("The queue is empty");
	 
   return data[head];
}
/* rear method  
*  @return item that is at the back of the queue
*/
public T rear ()throws QueueException {
	
	if (isEmpty()) throw new QueueException("The queue is empty");
	if (tail==0) return data[data.length-1];
   else return data[tail-1];
	
}

/* toString method  
*  @return String of the queue
*/
public String toString(){
	String str= "";
   
   if (isEmpty()){
	   str+="Queue is empty! Maximum number of items that can be stored is "+data.length;    
      return str;}
   else{
      str+= "The number of items in the queue is: " + size;
      str+= "\nThe queue contains the following: ";
      for (int index=head; index<size; index++){
      str= str+ data[index]+" ";}
      return str;}
  	
}

/* makeEmpty method empties all the itemps on the queue  
*  
*/

public void makeEmpty (){
   while(size!=0){
      dequeue();
   }
}

}
