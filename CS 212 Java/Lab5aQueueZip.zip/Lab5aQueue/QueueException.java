

public class QueueException extends RuntimeException{

/* QueueException Constructor
*  @param msg message to display when QueueException is thrown
*/
   
   public QueueException (String msg){
      super (msg);
   
   }
/* QueueException default Constructor
*  Displays default message when QueueException is thrown
*/
   
   public QueueException (){
   
      super("QueueException");
   }
   

}