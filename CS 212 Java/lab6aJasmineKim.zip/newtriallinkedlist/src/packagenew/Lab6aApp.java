package packagenew;

/**
 * <p>Title: Driver Class - Lab6aApp</p>
 *
 * <p>Copyright: Copyright (c) 2018</p>
 *
 * @author A. Abreu
 * @version 1.0
 */
import java.sql.*;

public class Lab6aApp {

	/**
	 * getData method -- gets the products from an SQLite database
	 * @return the an array of products
	 */
	public static Product[] getData(){		
		Statement stmt = null;
		int records = 0;
		Product[] products = null; 
		try {
			Class.forName("org.sqlite.JDBC");
			Connection c = DriverManager.getConnection("jdbc:sqlite:products.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");			

			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM products;");
			ResultSetMetaData rsmd = rs.getMetaData();			
			
			for(int i = 1; i <= rsmd.getColumnCount(); i++)	{
				System.out.print(String.format("%-12s", rsmd.getColumnLabel(i)) + "\t");
				System.out.print(rsmd.getColumnTypeName(i) + "\t");
				System.out.println(rsmd.getPrecision(i));
			}
			
			rs = stmt.executeQuery("select count (*) AS totalRecords from products");
			int totalRecords = rs.getInt("totalRecords");
			System.out.println("Records: " + totalRecords);
			
			rs = stmt.executeQuery("SELECT * FROM products;");
			if(rs != null){
				products = new Product[totalRecords];
				while (rs.next()) {
					String prodId = rs.getString("prodId");
					int quantity = rs.getInt("quantity");
					double price = rs.getFloat("price");

					System.out.println(String.format("%3s %-6s %3d %6.2f",
							records, prodId, quantity, price));	
					products[records++] = new Product(prodId, quantity, price);
				}
				System.out.println();
			}
			
			stmt.close();
			c.commit();
			c.close();
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch(SQLException se){
			System.err.println(se.getClass().getName() + ": " + se.getMessage());
		}
		return products;
	}
	
	public static void main (String [] args) {
		UnorderedArrayList <Product> list1 = new UnorderedArrayList<Product> ();
		System.out.println (list1);
		
		UnorderedArrayList <Product> list2 = new UnorderedArrayList<Product> (5);
		System.out.println (list2);
		
		Product [] products = getData();
		
		for (int i=0; i<5; i++) {
			list2.add(products [i]);
				
		}
		
		System.out.println (list2);
		
		
		//Product key2 = list2.get(0);
		//list2.testRemove(key2);
		
		Product item = new Product ("344d97", 5, 2);
		testRemove (item, list2);
		
		System.out.print("List after testRemove method: \n"+list2);
	
		list2.remove (0);
		list2.remove(products[4]);
		
		System.out.print("List2 after removing first and last items: \n"+list2);
		
		list1.add(new Product ("684x97", 5, 10));
		list1.remove(0);
		System.out.print("List1 after removing first item: \n"+list1);
		
		//Commenting out the equals method in the Product class does not make
		//a difference in the output for equals method has not been called. 
	}
	
	public static void testRemove (Product key, UnorderedArrayList ulist) {
		if (ulist.contains(key)) {ulist.remove(key); System.out.println ("Item "+key+" removed");}
		else System.out.println("Product "+ key +"not found");
		
	}
}